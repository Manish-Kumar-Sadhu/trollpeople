//
//  constants.swift
//  LottieDemo
//
//  Created by Mohammed Saif on 01/02/20.
//  Copyright © 2020 AppCoda. All rights reserved.
//

import Foundation

var gamificationAlertText = "😀 New Game Unlock Alert 🏆"

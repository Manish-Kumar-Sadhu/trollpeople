//
//  ViewController.swift
//  LottieDemo
//
//  Created by Simon Ng on 24/4/2017.
//  Copyright © 2017 AppCoda. All rights reserved.
//

import UIKit
import Lottie

enum characterType:String {
    case first
    case second
    case third
}

class ViewController: UIViewController {

    var count = 0
    @IBOutlet weak var controllerView: UIView!
    var controller: AccountDisplayViewController = AccountDisplayViewController()
    
    @IBOutlet weak var lockButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        laodAccountView(account: account[count])
        lockButton.setBackgroundImage(UIImage(named: "FavouriteButtonSelected"), for: .normal)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func showAnimation() {
        if let animationView = LOTAnimationView(name: "servishero_loading") {
        //        if let animationView = LOTAnimationView(contentsOf: URL(string: "https://github.com/isaeef/gamification_ios/blob/master/hero.json")!) {
                    animationView.frame = CGRect(x: 0, y: 0, width: 400, height: 400)
                    animationView.center = self.view.center
                    
                    animationView.loopAnimation = true
                    animationView.contentMode = .scaleAspectFill
                    animationView.animationSpeed = 0.5
                    
                    // Applying UIView animation
                    let minimizeTransform = CGAffineTransform(scaleX: 0.1, y: 0.1)
                    animationView.transform = minimizeTransform
                    UIView.animate(withDuration: 3.0, delay: 0.0, options: [.repeat, .autoreverse], animations: {
                        animationView.transform = CGAffineTransform.identity
                    }, completion: nil)
                    
                    view.addSubview(animationView)
                
                    animationView.play()
                }
    }


    func laodAccountView(account:Account) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        controller = storyboard.instantiateViewController(withIdentifier: "AccountDisplayViewController") as! AccountDisplayViewController
        //add as a childviewcontroller
         //addChildViewController(controller)
        controller.accountDetails = account
         // Add the child's View as a subview
         self.controllerView.addSubview(controller.view)
         controller.view.frame = controllerView.bounds
         controller.view.autoresizingMask = [.flexibleWidth, .flexibleHeight]

         // tell the childviewcontroller it's contained in it's parent
          controller.didMove(toParentViewController: self)
    }

    @IBAction func nextButtonAction(_ sender: Any) {
        
        if count < account.count-1 {
            count += 1
            removeAccountView()
            self.laodAccountView(account: account[count])
        }
    }
    
    
    @IBAction func previousButtonAction(_ sender: Any) {
        if count > 0  {
            count -= 1
            removeAccountView()
            self.laodAccountView(account: account[count])
        }
    }
    
    func removeAccountView(){
        controller.willMove(toParentViewController: nil)
        controller.view.removeFromSuperview()
        controller.removeFromParentViewController()
    }
    
    @IBAction func lockButtonAction(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        var achievementcontroller = storyboard.instantiateViewController(withIdentifier: "AchievementViewController") as! AchievementViewController
        achievementcontroller.account = account[count]
        achievementcontroller.vc = self
        self.present(achievementcontroller, animated: true, completion: nil)
    }
}


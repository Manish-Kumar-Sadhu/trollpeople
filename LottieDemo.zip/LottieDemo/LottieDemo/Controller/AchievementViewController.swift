//
//  AchievementViewController.swift
//  LottieDemo
//
//  Created by Mohammed Saif on 01/02/20.
//  Copyright © 2020 AppCoda. All rights reserved.
//

import UIKit

class AchievementViewController: UIViewController {

    @IBOutlet weak var achievementAnimationView: UIView!
    @IBOutlet weak var achievementSuccessView: UIView!
    var account:Account?
    var vc:ViewController?
    override func viewDidLoad() {
        super.viewDidLoad()
        showAnimation(animateView: achievementAnimationView, jsonString: "10121-reward-trophy-animation")
        showAnimation(animateView: achievementSuccessView, jsonString: "1370-confetti")
        // Do any additional setup after loading the view.
    }
    
    @IBAction func dismissButtonAction(_ sender: Any) {
        self.dismiss(animated: false, completion: nil)
    }
    
    func showAnimation(animateView:UIView,jsonString:String) {
        let animationConfigureView = configureAnimationView(view:animateView, jsonString: jsonString)
        // Applying UIView animation
        let minimizeTransform = CGAffineTransform(scaleX: 0.1, y: 0.1)
        animationConfigureView.center.x = view.center.x-50
        animationConfigureView.center.y = view.center.y-150
        if jsonString == "1370-confetti" {
            animationConfigureView.center.x = view.center.x-10
            animationConfigureView.center.y = view.center.y-200
        }
        
        animationConfigureView.transform = minimizeTransform
            UIView.animate(withDuration: 3.0, delay: 0.0, options: [.repeat, .autoreverse], animations: {
                animationConfigureView.transform = CGAffineTransform.identity
            }, completion: nil)
            
            animateView.addSubview(animationConfigureView)
        
            animationConfigureView.play()
    }
    
    @IBAction func goToRewards(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let rewardsViewController = storyboard.instantiateViewController(withIdentifier: "RewardsViewController") as! RewardsViewController
        rewardsViewController.account = self.account
        self.dismiss(animated: false, completion: nil)
        vc!.present(rewardsViewController, animated: false, completion: nil)
        
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

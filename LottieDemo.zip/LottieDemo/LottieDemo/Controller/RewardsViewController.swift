//
//  RewardsViewController.swift
//  LottieDemo
//
//  Created by Mohammed Saif on 01/02/20.
//  Copyright © 2020 AppCoda. All rights reserved.
//

import UIKit


class RewardsViewController: UIViewController {
    @IBOutlet weak var rewardsLottieView: UIView!
    

    @IBOutlet weak var rewardsSuccesView: UIView!
    @IBOutlet weak var rewardsLabel: UILabel!
    var account:Account?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configureView()
        // Do any additional setup after loading the view.
    }
    
    func configureView(){
        if let accnt = account {
             rewardsLabel.text = "You have won \(accnt.lottieGenre) vouchers"
        }else {
            rewardsLabel.text = "You have won DBS vouchers"
        }
        
        showAnimation(animateView: rewardsLottieView, jsonString: "animatedGiftBox")
        showAnimation(animateView: rewardsSuccesView, jsonString: "1370-confetti")
    }
    
    
    @IBAction func dismissRewards(_ sender: Any) {
        self.dismiss(animated: false, completion: nil)
    }
    
    func showAnimation(animateView:UIView,jsonString:String) {
        let animationConfigureView = configureAnimationView(view:animateView, jsonString: jsonString)
        // Applying UIView animation
        let minimizeTransform = CGAffineTransform(scaleX: 0.1, y: 0.1)
        animationConfigureView.center.x = view.center.x-50
        animationConfigureView.center.y = view.center.y-150
        
        if jsonString == "1370-confetti" {
            animationConfigureView.center.x = view.center.x-10
            animationConfigureView.center.y = view.center.y-200
        }
        
        animationConfigureView.transform = minimizeTransform
            UIView.animate(withDuration: 3.0, delay: 0.0, options: [.repeat, .autoreverse], animations: {
                animationConfigureView.transform = CGAffineTransform.identity
            }, completion: nil)
            
            animateView.addSubview(animationConfigureView)
        
            animationConfigureView.play()
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

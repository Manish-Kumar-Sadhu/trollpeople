//
//  AccountDisplayViewController.swift
//  LottieDemo
//
//  Created by Mohammed Saif on 31/01/20.
//  Copyright © 2020 AppCoda. All rights reserved.
//

import UIKit

class AccountDisplayViewController: UIViewController {

    @IBOutlet weak var boxAnimationView: UIView!
    @IBOutlet weak var gamificationAlertLabel: UILabel!
    @IBOutlet weak var alertView: UIView!
    @IBOutlet weak var animationView: UIView!
    
    @IBOutlet weak var profileView: UIView!
    
    
    @IBOutlet weak var profileImage: UIImageView!
    @IBOutlet weak var profileName: UILabel!
    
    
    @IBOutlet weak var levelOne: UILabel!
    
    @IBOutlet weak var levelOneProgress: UIProgressView!
    
    @IBOutlet weak var levelTwo: UILabel!
    
    @IBOutlet weak var levelTwoProgress: UIProgressView!
    
    @IBOutlet weak var levelThree: UILabel!
    
    @IBOutlet weak var levelThreeProgressView: UIProgressView!
    
    
    @IBOutlet weak var badgeView: UIView!
    
    var accountDetails:Account?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configureView()
        configureAccount()
        //showAnimation(animateView: boxAnimationView, jsonString: "servishero_loading")
        // Do any additional setup after loading the view.
    }
    
    
    func showAnimation(animateView:UIView,jsonString:String) {
        let animationConfigureView = configureAnimationView(view:animationView, jsonString: jsonString)
        // Applying UIView animation
        let minimizeTransform = CGAffineTransform(scaleX: 0.1, y: 0.1)
        animationConfigureView.transform = minimizeTransform
            UIView.animate(withDuration: 3.0, delay: 0.0, options: [.repeat, .autoreverse], animations: {
                animationConfigureView.transform = CGAffineTransform.identity
            }, completion: nil)
            
            animateView.addSubview(animationConfigureView)
        
            animationConfigureView.play()
    }

    
    func configureAccount() {
        if let accnt = self.accountDetails {
            showAnimation(animateView: animationView,jsonString:accnt.lottieGenre)
            profileName.text = accnt.accountName
            levelOne.text = accnt.levelOne
            levelTwo.text = accnt.levelTwo
            levelThree.text = accnt.levelThree
            //UIView.animate(withDuration: 4.0, animations: {
            self.levelOneProgress.setProgress(0.0, animated: false)
            self.levelTwoProgress.setProgress(0.0, animated: false)
            self.levelThreeProgressView.setProgress(0.0, animated: false)
            //})
            
            //self.progressView.setProgress(1.0, animated: false)

            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                
                self.levelOneProgress.setProgress(accnt.levelOneProgress, animated: true)
                self.levelTwoProgress.setProgress(accnt.levelTwoProgress, animated: true)
                self.levelThreeProgressView.setProgress(accnt.levelThreeProgress, animated: true)
            }
        }
    }
    
    func configureView(){
        gamificationAlertLabel.text = gamificationAlertText
        alertView.flash(animation: .opacity, withDuration: 1, repeatCount: 5)
        gamificationAlertLabel.flash(animation: .opacity, withDuration: 1, repeatCount: 5)
        alertView.layer.cornerRadius = 20.0
        animationView.layer.cornerRadius = 20.0
        profileView.layer.cornerRadius = 20.0
    }
    
    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

extension UIView {

    enum AnimationKeyPath: String {
        case opacity = "opacity"
    }

    func flash(animation: AnimationKeyPath ,withDuration duration: TimeInterval = 0.5, repeatCount: Float = 5){
        let flash = CABasicAnimation(keyPath: AnimationKeyPath.opacity.rawValue)
        flash.duration = duration
        flash.fromValue = 1 // alpha
        flash.toValue = 0 // alpha
        flash.timingFunction = CAMediaTimingFunction(name: kCAMediaTimingFunctionEaseInEaseOut)
        flash.autoreverses = true
        flash.repeatCount = repeatCount

        layer.add(flash, forKey: nil)
    }
}

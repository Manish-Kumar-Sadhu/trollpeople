//
//  Account.swift
//  LottieDemo
//
//  Created by Mohammed Saif on 31/01/20.
//  Copyright © 2020 AppCoda. All rights reserved.
//

import Foundation
struct Account {
    
    var accountName:String = ""
    var accountImage:String = ""
    var levelOne:String = ""
    var levelTwo:String = ""
    var levelThree:String = ""
    var levelOneProgress:Float = 0.0
    var levelTwoProgress:Float = 0.0
    var levelThreeProgress:Float = 0.0
    var lottieGenre:String = ""
    
    init(accountName:String, accountImage:String,
         levelOne:String,
         levelTwo:String,
         levelThree:String,
         levelOneProgress:Float, levelTwoProgress:Float,levelThreeProgress:Float,lottieGenre:String) {
        self.accountName = accountName
        self.accountImage = accountImage
        self.levelOne = levelOne
        self.levelTwo = levelTwo
        self.levelThree = levelThree
        self.levelOneProgress = levelOneProgress
        self.levelTwoProgress = levelTwoProgress
        self.levelThreeProgress = levelThreeProgress
        self.lottieGenre = lottieGenre
    }
}

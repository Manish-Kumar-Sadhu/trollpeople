//
//  Utilities.swift
//  LottieDemo
//
//  Created by Mohammed Saif on 31/01/20.
//  Copyright © 2020 AppCoda. All rights reserved.
//

import Foundation
import Lottie

var account = [Account(accountName: "Adventurer", accountImage: "",
                       levelOne:"Travel Rookie",
                       levelTwo:"Pro Traveller",
                       levelThree:"Expedite",
                       levelOneProgress: 0.5,
                       levelTwoProgress: 0.6,
                       levelThreeProgress: 0.2,
                       lottieGenre:"adventure"),
               Account(accountName: "Financial Wizards", accountImage: "",
                       levelOne:"Rookie Invester",
                       levelTwo:"Smart Invester",
                       levelThree:"Wolf of Wall Street",
                       levelOneProgress: 0.7,
                       levelTwoProgress: 0.1,
                       levelThreeProgress: 0.3,
                       lottieGenre:"finWizard"),
               Account(accountName: "Foodie", accountImage: "",
                       levelOne:"Foodie",
                       levelTwo:"MasterTaster",
                       levelThree:"MichelenStar",
                       levelOneProgress: 0.5,
                       levelTwoProgress: 0.6,
                       levelThreeProgress: 0.2,
                       lottieGenre:"foodie"),
               Account(accountName: "BingeWatcher", accountImage: "",
                       levelOne:"Movie Bluff",
                       levelTwo:"ProBinger",
                       levelThree:"Couch King",
                       levelOneProgress: 0.5,
                       levelTwoProgress: 0.6,
                       levelThreeProgress: 0.2,
                       lottieGenre:"bingeWatcher"),
               Account(accountName: "Shopholic", accountImage: "",
                       levelOne:"Apprentice",
                       levelTwo:"Compulsive Shopper",
                       levelThree:"Shopping Spree  ",
                       levelOneProgress: 0.5,
                       levelTwoProgress: 0.6,
                       levelThreeProgress: 0.2,
                       lottieGenre:"shopaHolic"),
               Account(accountName: "Party Goer", accountImage: "",
               levelOne:"Early Party Arriver",
               levelTwo:"GoodTime Charlie",
               levelThree:"Fan Frenzy ",
               levelOneProgress: 0.5,
               levelTwoProgress: 0.6,
               levelThreeProgress: 0.2,
               lottieGenre:"partyFreak")
]


func configureAnimationView(view:UIView,jsonString:String) -> LOTAnimationView{
    if let animationView = LOTAnimationView(name: jsonString) {
    //        if let animationView = LOTAnimationView(contentsOf: URL(string: "https://github.com/isaeef/gamification_ios/blob/master/hero.json")!) {
        animationView.frame = view.frame
        animationView.bounds = view.bounds
        animationView.center = view.center
        animationView.center.x = view.center.x-20
        animationView.center.y = view.center.y-120
        animationView.loopAnimation = true
        animationView.contentMode = .scaleAspectFill
        animationView.animationSpeed = 0.5
        
        // Applying UIView animation
        let minimizeTransform = CGAffineTransform(scaleX: 0.1, y: 0.1)
        animationView.transform = minimizeTransform
        return animationView
    }
    return LOTAnimationView()
}
